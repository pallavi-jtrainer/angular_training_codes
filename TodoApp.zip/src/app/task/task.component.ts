import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent {

  newTask: string;
  todos: any;
  todoObj: any;

  constructor() {
    this.newTask = '';
    this.todos = [];
  }


  addTask(event) {
    this.todoObj = {
      newTask: this.newTask,
      completed: false
    };
    this.todos.push(this.todoObj);
    this.newTask = '';
  }

}
